package com.example.un3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
